# SpendWise website (email login, one private account per person)

Each person creates an account with email + password. Their data is stored under their own account in Firebase (Auth + Firestore, free Spark plan is enough) and syncs across their devices. Nobody can see anyone else's data (see firestore.rules).

Until you paste your Firebase config, the site runs in single-user "local mode" (no login), exactly like before.

## A. One-time Firebase setup (about 5 minutes)
1. Go to https://console.firebase.google.com > **Add project** (name it e.g. spendwise). Analytics can be off.
2. **Build > Authentication > Get started > Sign-in method > Email/Password > Enable > Save.**
3. **Build > Firestore Database > Create database** > choose a region > **Production mode**.
4. Firestore > **Rules** tab > paste the contents of `firestore.rules` > **Publish**.
5. **Project settings (gear) > Your apps > Web (</>)** > register app > copy the `firebaseConfig` values into `public/firebase-config.js`.
6. Put your project id in `.firebaserc` (replace YOUR_PROJECT_ID).

## B. Deploy (pick one)
### Option 1 - Firebase Hosting (recommended, free)
```bash
npm install -g firebase-tools
firebase login
firebase deploy
```
You get https://YOUR_PROJECT_ID.web.app (already an authorized login domain).

### Option 2 - Netlify (drag and drop)
Drag the **public** folder onto https://app.netlify.com/drop. Then in Firebase: **Authentication > Settings > Authorized domains > Add domain** and add your `xxxx.netlify.app` domain. Without this, login is blocked.

### Option 3 - GitHub Pages / Vercel
Upload the contents of `public/`. Add the resulting domain to Firebase Authorized domains as above.

## C. Test
1. Open the site > **Create account** (name, email, password) > complete Salary setup.
2. Add an expense. In Firebase console > Firestore > `users` you will see one document for your user id.
3. Sign out (gear > Data > Sign out), create a second account: it starts empty (private).
4. Sign in on another device/browser with the first account: your data appears.

## Move your old local data
Old version: gear > Data > **Copy backup**. New site, after signing in: gear > Data > paste > **Restore backup**.

## Notes
- Password reset: "Forgot password?" on the login screen sends a reset email.
- One account document holds all data (limit about 1 MB, thousands of expenses). Tell me if you need to go beyond that.
- Sign out clears this device's cached copy after syncing it to the cloud.
- Phone alarms (notifications while closed) need the Android app; the website shows in-app alerts and browser notifications only while open.
